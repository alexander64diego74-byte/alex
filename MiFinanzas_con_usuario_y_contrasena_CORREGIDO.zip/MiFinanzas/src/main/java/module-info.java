module pe.edu.upeu.mifinanzas {

    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.slf4j;

    opens pe.edu.upeu.mifinanzas to javafx.fxml;

    exports pe.edu.upeu.mifinanzas;
}