package pe.edu.upeu.mifinanzas;
public final class Session {
    private static int userId;
    private static String username;
    private Session() {}
    public static void start(int id, String name) { userId=id; username=name; }
    public static int getUserId() { return userId; }
    public static String getUsername() { return username; }
    public static void close() { userId=0; username=null; }
}
