package pe.edu.upeu.mifinanzas;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginView {
    private final Stage stage;
    private final AuthDAO auth=new AuthDAO();

    public LoginView(Stage stage) { this.stage=stage; showLogin(); }

    private void showLogin() {
        VBox card=new VBox(13); card.setAlignment(Pos.CENTER); card.setPadding(new Insets(35));
        card.setMaxWidth(390);
        card.setStyle("-fx-background-color:white;-fx-background-radius:18;-fx-effect:dropshadow(gaussian,#cbd5e1,18,0,0,4);");
        Label title=new Label("MI FINANZAS");
        title.setStyle("-fx-font-size:27px;-fx-font-weight:bold;-fx-text-fill:#202B46;");
        Label subtitle=new Label("Inicia sesión para administrar tu dinero");
        TextField user=new TextField(); user.setPromptText("Nombre de usuario"); user.setPrefHeight(42);
        PasswordField pass=new PasswordField(); pass.setPromptText("Contraseña"); pass.setPrefHeight(42);
        Label message=new Label(); message.setStyle("-fx-text-fill:#c0392b;");
        Button login=new Button("Iniciar sesión"); login.setMaxWidth(Double.MAX_VALUE); login.setPrefHeight(42);
        login.setStyle("-fx-background-color:#3b00a3;-fx-text-fill:white;-fx-font-weight:bold;-fx-background-radius:8;");
        Button register=new Button("Crear una cuenta"); register.setMaxWidth(Double.MAX_VALUE);
        login.setOnAction(e->{
            try {
                int id=auth.login(user.getText(),pass.getText());
                if(id>0){ Session.start(id,user.getText().trim()); new HelloApplication().openMain(stage); }
                else message.setText("Usuario o contraseña incorrectos.");
            } catch(Exception ex){message.setText("No se pudo iniciar sesión: "+ex.getMessage());}
        });
        pass.setOnAction(e->login.fire());
        register.setOnAction(e->showRegister());
        card.getChildren().addAll(title,subtitle,user,pass,login,register,message);
        show(card,"Mi Finanzas - Inicio de sesión",520,460);
    }

    private void showRegister() {
        VBox card=new VBox(12); card.setAlignment(Pos.CENTER); card.setPadding(new Insets(30)); card.setMaxWidth(410);
        card.setStyle("-fx-background-color:white;-fx-background-radius:18;-fx-effect:dropshadow(gaussian,#cbd5e1,18,0,0,4);");
        Label title=new Label("Crear cuenta"); title.setStyle("-fx-font-size:24px;-fx-font-weight:bold;-fx-text-fill:#202B46;");
        TextField name=new TextField(); name.setPromptText("Nombre completo");
        TextField email=new TextField(); email.setPromptText("Correo electrónico");
        TextField user=new TextField(); user.setPromptText("Nombre de usuario");
        PasswordField pass=new PasswordField(); pass.setPromptText("Contraseña (mínimo 6 caracteres)");
        Label message=new Label(); message.setWrapText(true); message.setStyle("-fx-text-fill:#c0392b;");
        Button save=new Button("Registrarme"); save.setMaxWidth(Double.MAX_VALUE); save.setPrefHeight(40);
        Button back=new Button("Volver al inicio de sesión"); back.setMaxWidth(Double.MAX_VALUE);
        save.setStyle("-fx-background-color:#3b00a3;-fx-text-fill:white;-fx-font-weight:bold;");
        save.setOnAction(e->{
            try { auth.register(user.getText(),pass.getText(),name.getText(),email.getText());
                new Alert(Alert.AlertType.INFORMATION,"Cuenta creada correctamente. Ahora inicia sesión.").showAndWait();
                showLogin();
            } catch(Exception ex){message.setText(ex.getMessage());}
        });
        back.setOnAction(e->showLogin());
        card.getChildren().addAll(title,name,email,user,pass,save,back,message);
        show(card,"Mi Finanzas - Registro",540,560);
    }

    private void show(javafx.scene.Node content,String title,int w,int h) {
        StackPane root=new StackPane(content); root.setPadding(new Insets(25)); root.setStyle("-fx-background-color:#F3F5FA;");
        stage.setTitle(title); stage.setMinWidth(480); stage.setMinHeight(420);
        stage.setScene(new Scene(root,w,h)); stage.centerOnScreen(); stage.show();
    }
}
