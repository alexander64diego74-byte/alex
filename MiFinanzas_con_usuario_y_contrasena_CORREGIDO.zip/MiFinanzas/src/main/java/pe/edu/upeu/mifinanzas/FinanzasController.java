package pe.edu.upeu.mifinanzas;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.fxml.FXML;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;

public class FinanzasController {

    @FXML
    private Label lblUsuario;

    @FXML
    private TextField txtDescripcion;

    @FXML
    private TextField txtMonto;

    @FXML
    private ComboBox<String> cmbTipo;

    @FXML
    private TableView<Movimiento> tablaMovimientos;

    @FXML
    private TableColumn<Movimiento, String> colFecha;

    @FXML
    private TableColumn<Movimiento, String> colDescripcion;

    @FXML
    private TableColumn<Movimiento, String> colTipo;

    @FXML
    private TableColumn<Movimiento, Double> colMonto;

    @FXML
    private Label lblIngresos;

    @FXML
    private Label lblGastos;

    @FXML
    private Label lblSaldo;

    private final FinanzasDAO dao =
            new FinanzasDAO();

    private final ObservableList<Movimiento>
            movimientos =
            FXCollections.observableArrayList();

    @FXML
    public void initialize() {

        if (lblUsuario != null) {
            lblUsuario.setText("Usuario: " + Session.getUsername());
        }

        cmbTipo.getItems().addAll(
                "Ingreso",
                "Gasto"
        );

        cmbTipo.setValue("Ingreso");

        colFecha.setCellValueFactory(
                new PropertyValueFactory<>("fecha")
        );

        colDescripcion.setCellValueFactory(
                new PropertyValueFactory<>(
                        "descripcion"
                )
        );

        colTipo.setCellValueFactory(
                new PropertyValueFactory<>("tipo")
        );

        colMonto.setCellValueFactory(
                new PropertyValueFactory<>("monto")
        );

        cargarMovimientos();

        actualizarResumen();
    }

    @FXML
    private void registrarMovimiento() {

        String descripcion =
                txtDescripcion
                        .getText()
                        .trim();

        String montoTexto =
                txtMonto
                        .getText()
                        .trim();

        String tipo =
                cmbTipo.getValue();

        if (descripcion.isEmpty()
                || montoTexto.isEmpty()) {

            mostrarAlerta(
                    "Campos incompletos",
                    "Completa la descripción y el monto."
            );

            return;
        }

        double monto;

        try {

            monto = Double.parseDouble(
                    montoTexto.replace(",", ".")
            );

        } catch (NumberFormatException e) {

            mostrarAlerta(
                    "Monto inválido",
                    "Ingresa un número válido."
            );

            return;
        }

        if (monto <= 0) {

            mostrarAlerta(
                    "Monto inválido",
                    "El monto debe ser mayor que 0."
            );

            return;
        }

        Movimiento movimiento =
                new Movimiento(

                        0,

                        LocalDate.now().toString(),

                        descripcion,

                        tipo,

                        monto
                );

        dao.insertar(movimiento);

        txtDescripcion.clear();

        txtMonto.clear();

        cmbTipo.setValue("Ingreso");

        cargarMovimientos();

        actualizarResumen();
    }

    @FXML
    private void eliminarMovimiento() {

        Movimiento seleccionado =
                tablaMovimientos
                        .getSelectionModel()
                        .getSelectedItem();

        if (seleccionado == null) {

            mostrarAlerta(
                    "Selecciona un movimiento",
                    "Selecciona un movimiento de la tabla para eliminarlo."
            );

            return;
        }

        Alert confirmacion =
                new Alert(
                        Alert.AlertType.CONFIRMATION
                );

        confirmacion.setTitle(
                "Eliminar movimiento"
        );

        confirmacion.setHeaderText(null);

        confirmacion.setContentText(
                "¿Deseas eliminar este movimiento?"
        );

        if (
                confirmacion
                        .showAndWait()
                        .orElse(ButtonType.CANCEL)
                        == ButtonType.OK
        ) {

            dao.eliminar(
                    seleccionado.getId()
            );

            cargarMovimientos();

            actualizarResumen();
        }
    }

    private void cargarMovimientos() {

        movimientos.setAll(
                dao.listar()
        );

        tablaMovimientos.setItems(
                movimientos
        );
    }

    private void actualizarResumen() {

        double ingresos =
                dao.obtenerIngresos();

        double gastos =
                dao.obtenerGastos();

        double saldo =
                dao.obtenerSaldo();

        lblIngresos.setText(
                String.format(
                        "S/ %.2f",
                        ingresos
                )
        );

        lblGastos.setText(
                String.format(
                        "S/ %.2f",
                        gastos
                )
        );

        lblSaldo.setText(
                String.format(
                        "S/ %.2f",
                        saldo
                )
        );
    }

    @FXML
    private void cerrarSesion() {
        Session.close();
        Stage stage = (Stage) tablaMovimientos.getScene().getWindow();
        new LoginView(stage);
    }

    private void mostrarAlerta(
            String titulo,
            String mensaje
    ) {

        Alert alerta =
                new Alert(
                        Alert.AlertType.WARNING
                );

        alerta.setTitle(titulo);

        alerta.setHeaderText(null);

        alerta.setContentText(mensaje);

        alerta.showAndWait();
    }
}