package pe.edu.upeu.mifinanzas;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.*;

public class HelloApplication extends Application {
    private static final String URL="jdbc:sqlite:data/finanzas.db";
    @Override public void start(Stage stage) {
        initializeDatabase();
        new LoginView(stage);
    }
    private void initializeDatabase() {
        try {
            java.nio.file.Files.createDirectories(java.nio.file.Path.of("data"));
            try(Connection c=DriverManager.getConnection(URL); Statement s=c.createStatement()) {
                s.execute("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, salt TEXT NOT NULL, nombre_completo TEXT NOT NULL, correo TEXT NOT NULL UNIQUE, creado_en TEXT DEFAULT CURRENT_TIMESTAMP)");
                s.execute("CREATE TABLE IF NOT EXISTS movimientos (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT NOT NULL, descripcion TEXT NOT NULL, tipo TEXT NOT NULL, monto REAL NOT NULL)");
                try(ResultSet rs=s.executeQuery("PRAGMA table_info(movimientos)")) {
                    boolean exists=false;
                    while(rs.next()) if("usuario_id".equalsIgnoreCase(rs.getString("name"))) exists=true;
                    if(!exists) s.execute("ALTER TABLE movimientos ADD COLUMN usuario_id INTEGER REFERENCES usuarios(id)");
                }
                s.execute("CREATE INDEX IF NOT EXISTS idx_movimientos_usuario ON movimientos(usuario_id)");
            }
        } catch(Exception e) { throw new RuntimeException("No se pudo preparar la base de datos: "+e.getMessage(),e); }
    }

    public void openMain(Stage stage) {
        try {
            FXMLLoader loader=new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
            Scene scene=new Scene(loader.load(),1180,780);
            stage.setTitle("Mi Finanzas - "+Session.getUsername());
            stage.setMinWidth(900); stage.setMinHeight(650);
            stage.setScene(scene); stage.centerOnScreen(); stage.show();
        } catch(IOException e) { throw new RuntimeException("No se pudo abrir el panel principal.",e); }
    }
    public static void main(String[] args) { launch(args); }
}
