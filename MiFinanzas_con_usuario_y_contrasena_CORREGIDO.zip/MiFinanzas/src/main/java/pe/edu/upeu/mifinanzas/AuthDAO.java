package pe.edu.upeu.mifinanzas;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.sql.*;
import java.util.Base64;

public class AuthDAO {
    private static final String URL="jdbc:sqlite:data/finanzas.db";

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    private String hash(String password, byte[] salt) throws Exception {
        PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,120000,256);
        byte[] result=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).getEncoded();
        spec.clearPassword();
        return Base64.getEncoder().encodeToString(result);
    }

    public void register(String username,String password,String fullName,String email) throws Exception {
        username=username.trim(); fullName=fullName.trim(); email=email.trim();
        if(username.isBlank() || fullName.isBlank() || email.isBlank() || password.length()<6)
            throw new IllegalArgumentException("Completa todos los campos. La contraseña debe tener al menos 6 caracteres.");
        byte[] salt=new byte[16]; new SecureRandom().nextBytes(salt);
        String saltText=Base64.getEncoder().encodeToString(salt);
        String passHash=hash(password,salt);
        String sql="INSERT INTO usuarios(username,password_hash,salt,nombre_completo,correo) VALUES(?,?,?,?,?)";
        try(Connection c=connect(); PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,username); ps.setString(2,passHash); ps.setString(3,saltText);
            ps.setString(4,fullName); ps.setString(5,email); ps.executeUpdate();
        } catch(SQLException ex) {
            if(ex.getMessage()!=null && ex.getMessage().toLowerCase().contains("unique"))
                throw new IllegalArgumentException("Ese usuario o correo ya está registrado.");
            throw ex;
        }
    }

    public int login(String username,String password) throws Exception {
        String sql="SELECT id,password_hash,salt FROM usuarios WHERE username=?";
        try(Connection c=connect(); PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,username.trim());
            try(ResultSet rs=ps.executeQuery()) {
                if(!rs.next()) return -1;
                byte[] salt=Base64.getDecoder().decode(rs.getString("salt"));
                return hash(password,salt).equals(rs.getString("password_hash")) ? rs.getInt("id") : -1;
            }
        }
    }
}
