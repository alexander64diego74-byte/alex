package pe.edu.upeu.mifinanzas;

import java.sql.*;
import java.util.*;

public class FinanzasDAO {
    private static final String URL="jdbc:sqlite:data/finanzas.db";
    private Connection conectar() throws SQLException {
        if(Session.getUserId()<=0) throw new SQLException("No hay una sesión iniciada.");
        return DriverManager.getConnection(URL);
    }
    public void insertar(Movimiento m) {
        String sql="INSERT INTO movimientos(fecha,descripcion,tipo,monto,usuario_id) VALUES(?,?,?,?,?)";
        try(Connection c=conectar();PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,m.getFecha()); p.setString(2,m.getDescripcion()); p.setString(3,m.getTipo());
            p.setDouble(4,m.getMonto()); p.setInt(5,Session.getUserId()); p.executeUpdate();
        } catch(SQLException e){throw new RuntimeException("Error al guardar movimiento: "+e.getMessage(),e);}
    }
    public List<Movimiento> listar() {
        List<Movimiento> list=new ArrayList<>();
        String sql="SELECT id,fecha,descripcion,tipo,monto FROM movimientos WHERE usuario_id=? ORDER BY id DESC";
        try(Connection c=conectar();PreparedStatement p=c.prepareStatement(sql)) {
            p.setInt(1,Session.getUserId());
            try(ResultSet r=p.executeQuery()){while(r.next())list.add(new Movimiento(r.getInt("id"),r.getString("fecha"),r.getString("descripcion"),r.getString("tipo"),r.getDouble("monto")));}
        } catch(SQLException e){throw new RuntimeException("Error al listar movimientos: "+e.getMessage(),e);}
        return list;
    }
    public void eliminar(int id) {
        try(Connection c=conectar();PreparedStatement p=c.prepareStatement("DELETE FROM movimientos WHERE id=? AND usuario_id=?")) {
            p.setInt(1,id);p.setInt(2,Session.getUserId());p.executeUpdate();
        } catch(SQLException e){throw new RuntimeException("Error al eliminar movimiento: "+e.getMessage(),e);}
    }
    public double obtenerIngresos(){return total("Ingreso");}
    public double obtenerGastos(){return total("Gasto");}
    public double obtenerSaldo(){return obtenerIngresos()-obtenerGastos();}
    private double total(String tipo) {
        try(Connection c=conectar();PreparedStatement p=c.prepareStatement("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE tipo=? AND usuario_id=?")) {
            p.setString(1,tipo);p.setInt(2,Session.getUserId());
            try(ResultSet r=p.executeQuery()){return r.next()?r.getDouble(1):0;}
        } catch(SQLException e){throw new RuntimeException("Error al calcular resumen: "+e.getMessage(),e);}
    }
}
